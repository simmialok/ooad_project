from django.db import models
from django.contrib.auth.models import AbstractUser
import datetime
import django.utils.timezone
# Create your models here.


class Flight(models.Model):
    flight_no = models.IntegerField(primary_key=True, default=1000)
    airline_name = models.CharField(max_length=50)
    no_of_seats = models.IntegerField(default=0)
    source = models.CharField(max_length=50)
    source_code = models.CharField(max_length=3)
    destination = models.CharField(max_length=50)
    destination_code = models.CharField(max_length=3)
    arrival_time = models.DateTimeField()
    departure_time = models.DateTimeField()

class User(AbstractUser):
    USER_TYPE_CHOICES = (
      (1, 'flightstaff'),
      (2, 'security'),
      (3, 'admin'),
    )

    user_type = models.PositiveSmallIntegerField(choices=USER_TYPE_CHOICES, default=3)


class Passenger(models.Model):
    pnr = models.CharField(max_length=10,null=True,blank=True)
    first_name = models.CharField(max_length=50,null=True,blank=True)
    last_name = models.CharField(max_length=50,null=True,blank=True)
    dob = models.DateField(default=1/1/1990,null=True,blank=True)
    nationality = models.CharField(max_length=50,null=True,blank=True)
    gender = models.CharField(max_length=1,null=True,blank=True)
    # email = models.EmailField(null=True, blank=True)
    disability_attendant_care = models.CharField(max_length=1,null=True,blank=True)
    meals_and_beverages = models.CharField(max_length=1, null=True, blank=True)
    flight_no = models.ForeignKey(Flight, on_delete=models.CASCADE,null=True,blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE,null=True,blank=True)
   # type_of_trip = models.CharField(null=True, blank=True,max_length=20)
    checked_in_status = models.BooleanField(default=0,null=True,blank=True)
    cleared_security_status = models.IntegerField(default=0,null=True,blank=True)

class Security(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=2)
    id = models.IntegerField(primary_key=True)

class Staff(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=1)
    id = models.IntegerField(primary_key=True)
    flight_no = models.ForeignKey(Flight, on_delete=models.CASCADE, default=1000)
